export interface IdentityContractPlaceholder {}
