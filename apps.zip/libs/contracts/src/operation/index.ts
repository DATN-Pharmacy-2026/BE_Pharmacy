export interface OperationContractPlaceholder {}
