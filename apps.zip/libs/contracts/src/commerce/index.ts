export interface CommerceContractPlaceholder {}
