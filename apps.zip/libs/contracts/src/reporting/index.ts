export interface ReportingContractPlaceholder {}
