export interface NotificationContractPlaceholder {}
